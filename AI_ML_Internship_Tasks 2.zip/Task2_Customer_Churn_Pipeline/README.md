<center>
    <h2 style="color:#2196F3; text-shadow: 0 0 5px #2196F3, 0 0 10px #64B5F6;">
        📊 <strong>Task 2: Customer Churn Prediction Pipeline</strong> 🧮
    </h2>
    <p><em>🔍 Build a reusable ML pipeline for churn prediction using scikit-learn</em></p>
</center>

---

## 🧠 Objective
Predict customer churn using a production-ready ML pipeline.

## 📚 Dataset
- [Telco Customer Churn](https://www.kaggle.com/blastchar/telco-customer-churn)

## 🛠️ Tools & Libraries
- Scikit-learn
- Pandas
- Joblib

## 🧪 Steps Followed
1. Data cleaning, encoding, and scaling
2. RandomForest model with GridSearchCV
3. Exported trained pipeline with `joblib`

## 📊 Results
| Model            | Accuracy |
|------------------|----------|
| Random Forest    | ~82%     |

## 💾 Output
Model saved as: `churn_pipeline.joblib`
