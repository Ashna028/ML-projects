import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import joblib

# Load dataset
data = pd.read_csv("https://raw.githubusercontent.com/blastchar/telco-customer-churn/master/WA_Fn-UseC_-Telco-Customer-Churn.csv")

data.dropna(inplace=True)
data.drop(["customerID"], axis=1, inplace=True)

# Encode target
data["Churn"] = data["Churn"].map({"Yes": 1, "No": 0})

# Features/labels
X = data.drop("Churn", axis=1)
y = data["Churn"]

# Preprocessing
categorical = X.select_dtypes(include=["object"]).columns
numerical = X.select_dtypes(exclude=["object"]).columns

preprocessor = ColumnTransformer([
    ("num", StandardScaler(), numerical),
    ("cat", OneHotEncoder(handle_unknown="ignore"), categorical)
])

pipeline = Pipeline([
    ("preprocess", preprocessor),
    ("clf", RandomForestClassifier())
])

# Train/test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
grid = GridSearchCV(pipeline, {"clf__n_estimators": [100, 200]}, cv=3)
grid.fit(X_train, y_train)

# Evaluation
print("Accuracy:", accuracy_score(y_test, grid.predict(X_test)))

# Save pipeline
joblib.dump(grid.best_estimator_, "churn_pipeline.joblib")
