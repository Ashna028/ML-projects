import streamlit as st
from transformers import pipeline
from streamlit_lottie import st_lottie
import requests

# Lottie animation loader
def load_lottie_url(url):
    r = requests.get(url)
    if r.status_code != 200:
        return None
    return r.json()

# Streamlit setup
st.set_page_config(page_title="BERT News Classifier", layout="centered")
st.title("📰 BERT-Powered News Topic Classifier")

st_lottie(load_lottie_url("https://assets1.lottiefiles.com/packages/lf20_urbk83vw.json"), height=200)

# Load classifier
classifier = pipeline("text-classification", model="./bert-news", tokenizer="./bert-news")

# Label mapping
label_map = {
    "LABEL_0": "World 🌍",
    "LABEL_1": "Sports ⚽",
    "LABEL_2": "Business 💼",
    "LABEL_3": "Sci/Tech 🔬"
}

# Input and prediction
user_input = st.text_input("Enter a news headline:")
if user_input:
    result = classifier(user_input)[0]
    label = label_map.get(result["label"], result["label"])
    score = round(result["score"] * 100, 2)
    st.markdown(f"### 🏷 Predicted Topic: **{label}**")
    st.markdown(f"**Confidence Score:** `{score}%`")
