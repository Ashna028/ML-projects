<center>
    <h2 style="color:#4CAF50; text-shadow: 0 0 5px #4CAF50, 0 0 10px #81C784;">
        🚀 <strong>Task 1: News Topic Classifier Using BERT</strong> 🧠
    </h2>
    <p><em>🔥 Fine-tune a Transformer Model for News Topic Prediction 🔥</em></p>
</center>

---

## 🧠 Objective
Fine-tune a BERT model to classify news headlines into topic categories (World, Sports, Business, Sci/Tech).

## 📚 Dataset
- **Source:** [AG News Dataset](https://huggingface.co/datasets/ag_news)
- **Classes:** World, Sports, Business, Sci/Tech

## 🛠️ Tools & Libraries
- Hugging Face Transformers
- Datasets
- PyTorch
- scikit-learn
- Streamlit
- streamlit-lottie

## 🧪 Steps Followed
1. Loaded and tokenized the dataset using `bert-base-uncased`
2. Fine-tuned BERT using Hugging Face `Trainer`
3. Evaluated using Accuracy and F1-score
4. Deployed with Streamlit and interactive UI

## 📊 Results
| Metric    | Value  |
|-----------|--------|
| Accuracy  | ~95%   |
| F1-Score  | ~94%   |

## 🚀 Deployment
Run this in terminal:
```bash
streamlit run streamlit_app.py
```

## 📂 Project Structure
```
Task1_News_Classifier_BERT/
├── train_model.py
├── streamlit_app.py
└── README.md
```
