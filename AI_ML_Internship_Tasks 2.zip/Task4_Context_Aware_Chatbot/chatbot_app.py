import streamlit as st
from langchain.chat_models import ChatOpenAI
from langchain.chains import ConversationalRetrievalChain
from langchain.vectorstores import Chroma
from langchain.document_loaders import TextLoader
from langchain.embeddings import OpenAIEmbeddings

# Setup
st.set_page_config(page_title="AI Chatbot", layout="centered")
st.title("🤖 Context-Aware Chatbot")

# Load documents
loader = TextLoader("knowledge.txt")
docs = loader.load()

# Embed and store
db = Chroma.from_documents(docs, OpenAIEmbeddings())
retriever = db.as_retriever()

# Chat LLM
llm = ChatOpenAI()
qa_chain = ConversationalRetrievalChain.from_llm(llm, retriever)

# UI
chat_history = []
query = st.text_input("Ask a question:")
if query:
    result = qa_chain({"question": query, "chat_history": chat_history})
    st.write(result["answer"])
    chat_history.append((query, result["answer"]))
