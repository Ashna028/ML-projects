<center>
    <h2 style="color:#FF9800; text-shadow: 0 0 5px #FF9800, 0 0 10px #FFB74D;">
        🗣️ <strong>Task 4: Context-Aware Chatbot Using LangChain</strong> 🧠
    </h2>
    <p><em>💬 Build a conversational AI with memory and document search</em></p>
</center>

---

## 🧠 Objective
Create a chatbot that retrieves information from a document and remembers conversation history.

## 📚 Dataset
- Custom knowledge file (`knowledge.txt`)

## 🛠️ Tools & Libraries
- LangChain
- OpenAI
- Chroma
- Streamlit

## 🧪 Steps Followed
1. Load documents and convert to vector store
2. Setup LangChain Retrieval QA with memory
3. Deployed chatbot using Streamlit

## 🗂️ Files
- `chatbot_app.py`
- `knowledge.txt`

## 🚀 Deployment
```bash
streamlit run chatbot_app.py
```
